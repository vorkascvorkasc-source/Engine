"""
Historical data loading utilities.

This module provides a function to load historical match data from
CSV files stored in the local `historical` directory.  The data can
be used for model training or backtesting.  The expected format of
the CSV files is sport-specific: files should be named
`<sport>_<season>.csv` and contain columns that the engine can
understand (e.g. match_id, home_team, away_team, league, kef,
result, etc.).

You can extend this loader to parse other file formats or to merge
multiple seasons on demand.
"""

from __future__ import annotations

import os
from typing import Optional

import pandas as pd


def load_historical_data(sport: str, season: Optional[str] = None) -> pd.DataFrame:
    """
    Load historical match data from CSV files.

    Parameters
    ----------
    sport : str
        Sport identifier (e.g. 'football', 'hockey', 'basketball', 'tennis').
    season : str or None, optional
        Season identifier.  If provided, the function looks for a
        file named `<sport>_<season>.csv` in the `historical`
        directory.  If None, it will attempt to load all files
        matching the sport prefix.

    Returns
    -------
    DataFrame
        Loaded data.  If no files are found, returns an empty
        DataFrame.
    """
    dir_path = "historical"
    if not os.path.exists(dir_path):
        return pd.DataFrame()
    if season:
        file_name = f"{sport}_{season}.csv"
        file_path = os.path.join(dir_path, file_name)
        if os.path.exists(file_path):
            return pd.read_csv(file_path)
        return pd.DataFrame()
    else:
        # Load all files starting with sport_ prefix
        frames = []
        for f in os.listdir(dir_path):
            if f.startswith(f"{sport}_") and f.endswith(".csv"):
                try:
                    frames.append(pd.read_csv(os.path.join(dir_path, f)))
                except Exception:
                    continue
        if frames:
            return pd.concat(frames, ignore_index=True)
        return pd.DataFrame()