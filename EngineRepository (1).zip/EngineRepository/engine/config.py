"""
Configuration settings for the betting engine.

This module defines a central `Config` class containing defaults for
odds ranges, bankroll management, ranking thresholds and file names.  It
also includes definitions for risk profiles and sport-specific risk
adjustments.  A helper function merges profiles with sport tweaks to
produce final risk parameters used by the engine.

The configuration values are defined at import time but can be
overridden at runtime by adjusting class attributes or by loading
environment variables where indicated.
"""

from __future__ import annotations

import os
from typing import Any, Dict


class Config:
    """
    Central configuration for the betting engine.

    This class contains default parameters for bankroll management,
    ranking thresholds, express behaviour and file names used for
    persisting model artefacts and caches.  Feel free to adjust these
    values based on your bankroll and appetite for risk.
    """

    # Odds and bankroll settings
    KEF_MIN: float = 1.18
    KEF_MAX: float = 4.20
    BANKROLL: float = 50_000.0
    MAX_BANK_FRACTION: float = 0.06
    MIN_STAKE: float = 15.0
    VALUE_THRESHOLD: float = 0.045

    # Supported sports (singles & expresses)
    SUPPORTED_SPORTS = ["football", "basketball", "tennis", "hockey"]

    # Rank thresholds: probability + value
    PRIORITY_THRESHOLDS: Dict[str, Dict[str, float]] = {
        "S":  {"prob": 0.88, "value": 0.12},
        "A+": {"prob": 0.84, "value": 0.09},
        "A":  {"prob": 0.79, "value": 0.07},
        "B":  {"prob": 0.72, "value": 0.04},
        "C":  {"prob": 0.0,  "value": 0.0},
    }

    # Express configuration
    EXPRESS_MAX_CANDIDATES: int = 20
    EXPRESS_DEFAULT_MAX_SIZE: int = 30

    # Files and directories
    MODEL_DIR: str = "models_unified"
    TRAINING_DATA_FILE: str = "training_data.csv"
    ROI_FILE: str = "roi_unified.csv"
    CACHE_FILE: str = "cache_unified.json"
    CAPPERS_FILE: str = "capper_unified.json"

    # External keys / services (stubs)
    API_SPORT_KEY: str = os.getenv("API_SPORT_KEY", "dummy_key")
    GROQ_API_KEY: str = os.getenv("GROQ_API_KEY", "")
    GROQ_MODEL: str = "llama3-70b-8192"

    # ML/uncertainty
    ALERT_THRESHOLD_EV: float = 0.03
    TEXT_VEC_LEN: int = 50
    ROLLING_RETRAIN_MATCHES: int = 200
    UNCERT_T1: float = 0.03
    UNCERT_T2: float = 0.08

    # Exposure limits per risk profile (class-level) to limit number
    # of matches per key (e.g. team, league) when selecting candidates.
    EXPOSURE_LIMITS: Dict[str, Dict[str, int]] = {
        "conservative": {
            "home_team": 1,
            "away_team": 1,
            "league": 2,
        },
        "balanced": {
            "home_team": 2,
            "away_team": 2,
            "league": 3,
        },
        "aggressive": {
            "home_team": 3,
            "away_team": 3,
            "league": 4,
        },
    }


# ======================== RISK PROFILES ========================

# Risk profiles define baseline behaviour for constructing singles and
# express bets.  Conservative profiles demand higher EV thresholds and
# smaller parlay sizes, whereas aggressive profiles accept lower EV and
# larger parlay sizes.  These values can be tweaked to fit your
# personal risk tolerance.

RISK_PROFILES: Dict[str, Dict[str, Any]] = {
    # Conservative players demand high EV and small parlays.  They
    # prefer Kelly staking but may cap the stake per bet.  Percent and
    # flat staking provide alternative options.
    "conservative": {
        "value_threshold": 0.06,
        "min_size": 2,
        "max_size": 8,
        "conf_weight": 1.2,
        "corr_weight": 1.2,
        "candidate_multiplier": 0.8,
        "capper_ev_weight": 0.5,
        "capper_noise_threshold": 2.0,
        # staking parameters
        "stake_strategy": "kelly",
        "percent_stake": 0.01,  # 1% of bank per bet
        "flat_stake": 25.0,      # flat stake amount
        # maximum percentage of the bankroll to allocate per day.  If total
        # stake on all singles exceeds bank * daily_stake_cap, stakes
        # will be scaled down proportionally.
        "daily_stake_cap": 0.10,
        # maximum number of matches to consider per sport when filtering
        # candidates (to diversify exposures).  Keys correspond to sport
        # names; values are counts.  Unspecified sports use no limit.
        "sport_exposure_limits": {
            "football": 5,
            "basketball": 5,
            "tennis": 5,
            "hockey": 5,
        },
        # dynamic EV scaling factor.  The final value threshold can be
        # adjusted based on the standard deviation of value: th_final =
        # base_threshold + ev_scale_factor * std(value).  Higher
        # factors reduce risk when value variance is high.
        "ev_scale_factor": 0.50,
        # rank-based stake multipliers: higher ranks receive larger stakes.
        # Values are multipliers applied to the computed stake (Kelly, percent or flat).
        # This allows risk profiles to emphasize high-quality picks.
        "rank_weights": {
            "S": 1.4,
            "A+": 1.3,
            "A": 1.2,
            "B": 1.0,
            "C": 0.8,
        },
        # Adjust stakes based on EV relative to the minimum value threshold.  A
        # positive factor will increase stakes for picks with EV well above the
        # threshold and decrease them for picks near the threshold (ratio is
        # clipped at zero below the threshold).  Use small values (e.g. 0.5) to
        # avoid overly aggressive scaling.
        "ev_weight_factor": 0.5,
        # default ML backend for this profile.  Supported values:
        # 'logreg', 'xgb', 'lgb', 'cat'.  See engine/ml.py for details.
        "ml_backend": "logreg",
        # limit the number of bets per league.  This helps diversify
        # singles across different competitions and avoids over-
        # concentration on a single tournament.  Only the top N
        # matches by value are kept per league.  Set to None or a
        # non-positive number to disable.  Conservative players
        # typically limit to 2 bets per league.
        "league_limit": 2,

        # Maximum number of singles to pick per league.  Limiting the
        # number of bets per league helps diversify exposures across
        # different competitions.  If ``league_limit`` is not set or
        # is ``None``, no per-league filtering is applied.  When set
        # to a positive integer, only the top ``league_limit`` matches
        # by expected value per league are kept after stake calculation.
        "league_limit": 2,
    },
    # Balanced profiles aim for moderate EV and medium parlay sizes.
    "balanced": {
        "value_threshold": 0.045,
        "min_size": 3,
        "max_size": 12,
        "conf_weight": 1.0,
        "corr_weight": 1.0,
        "candidate_multiplier": 1.0,
        "capper_ev_weight": 0.7,
        "capper_noise_threshold": 3.0,
        "stake_strategy": "kelly",
        "percent_stake": 0.015,  # 1.5% of bank per bet
        "flat_stake": 50.0,
        "daily_stake_cap": 0.20,
        "sport_exposure_limits": {
            "football": 8,
            "basketball": 8,
            "tennis": 8,
            "hockey": 8,
        },
        "ev_scale_factor": 0.30,
        "rank_weights": {
            "S": 1.5,
            "A+": 1.35,
            "A": 1.2,
            "B": 1.0,
            "C": 0.8,
        },
        # EV weighting factor: moderate weighting for balanced profile
        "ev_weight_factor": 1.0,
        "ml_backend": "xgb",
        # allow a moderate number of bets per league.  Keeping 3 bets
        # per league helps maintain diversity while still taking
        # advantage of good opportunities within a competition.
        "league_limit": 3,

        # Limit on number of singles per league.  Balanced players
        # accept more diversification than conservative ones.
        "league_limit": 3,
    },
    # Aggressive players accept low EV and large parlays.  They stake
    # aggressively and allow the capper EV to influence value more
    # strongly.
    "aggressive": {
        "value_threshold": 0.03,
        "min_size": 4,
        "max_size": 30,
        "conf_weight": 0.8,
        "corr_weight": 0.8,
        "candidate_multiplier": 1.5,
        "capper_ev_weight": 1.0,
        "capper_noise_threshold": 5.0,
        "stake_strategy": "kelly",
        "percent_stake": 0.02,  # 2% of bank per bet
        "flat_stake": 100.0,
        "daily_stake_cap": 0.30,
        "sport_exposure_limits": {
            "football": 15,
            "basketball": 15,
            "tennis": 15,
            "hockey": 15,
        },
        "ev_scale_factor": 0.10,
        "rank_weights": {
            "S": 1.7,
            "A+": 1.45,
            "A": 1.2,
            "B": 1.0,
            "C": 0.7,
        },
        # EV weighting factor: higher weighting for aggressive profile
        "ev_weight_factor": 1.5,
        "ml_backend": "cat",
        # aggressive players can accept more bets per league since
        # they are willing to take on higher risk.  A limit of 5
        # matches ensures some diversification but allows scaling up
        # when many high-EV opportunities arise.
        "league_limit": 5,
    },
}


# ======================== SPORT-SPECIFIC RISK ========================

# Sport-specific risk adjustments allow fine-tuning of EV thresholds,
# candidate pool sizes and weightings depending on the dynamics of each
# sport.  For example, hockey may have slightly lower EV thresholds
# because of higher volatility, while basketball might tolerate longer
# express lengths due to the abundance of scoring events.

SPORT_RISK_ADJUSTMENTS: Dict[str, Dict[str, Any]] = {
    "football": {
        "value_threshold": 0.05,
        "candidate_multiplier": 1.2,
    },
    "hockey": {
        "value_threshold": 0.04,
        "candidate_multiplier": 1.3,
        "corr_weight": 0.9,
    },
    "basketball": {
        "value_threshold": 0.035,
        "candidate_multiplier": 1.5,
        "conf_weight": 0.9,
    },
    "tennis": {
        "value_threshold": 0.04,
        "candidate_multiplier": 1.4,
    },
}



def build_risk_params(profile_name: str, sport: str | None) -> Dict[str, Any]:
    """
    Merge a base risk profile with sport-specific tweaks.

    This helper first takes the base profile from `RISK_PROFILES` and
    then applies any overrides defined in `SPORT_RISK_ADJUSTMENTS` for
    the given sport.  The resulting dictionary is used by the engine
    to control parlay sizes, EV thresholds and penalty weights.

    Parameters
    ----------
    profile_name: str
        Name of the risk profile (conservative, balanced or aggressive).
    sport: str or None
        Sport identifier to apply sport-specific adjustments.  If None
        or the sport is not recognised, only the base profile is used.

    Returns
    -------
    Dict[str, Any]
        A dictionary containing the merged parameters.
    """
    base = RISK_PROFILES.get(profile_name, RISK_PROFILES["balanced"]).copy()
    if sport and sport in SPORT_RISK_ADJUSTMENTS:
        for k, v in SPORT_RISK_ADJUSTMENTS[sport].items():
            base[k] = v
    return base