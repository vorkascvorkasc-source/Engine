"""
Backtesting utilities for the betting engine.

This package collects functions to simulate historical performance of
betting strategies.  Use these tools to evaluate how your model and
risk parameters would have performed on past seasons.
"""

from .engine import backtest_strategy

__all__ = ["backtest_strategy"]