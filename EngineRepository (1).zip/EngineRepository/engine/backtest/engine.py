"""
Historical backtesting engine.

This module provides utilities to simulate betting over historical
data.  Given a DataFrame containing match records with actual
results, it will iterate through each match, determine the stake
based on predicted probabilities and risk settings, and update the
bankroll accordingly.  The result is a summary of final bankroll,
ROI and performance metrics.

The module assumes that the DataFrame contains a `result` column
indicating match outcome (1 for win, 0 for loss) and a `kef` column
with decimal odds.  If probabilities are not provided, the engine
can be asked to compute them using its internal model.
"""

from __future__ import annotations

from typing import Dict, Any, Optional, List

import numpy as np
import pandas as pd

from ..config import Config, build_risk_params
from ..utils import kelly_fractional, compute_value
from ..ml import PredictionModel


def backtest_strategy(
    df: pd.DataFrame,
    *,
    sport: Optional[str] = None,
    risk_profile: str = "balanced",
    bank: float = Config.BANKROLL,
    use_provided_prob: bool = False,
    verbose: bool = False,
) -> Dict[str, Any]:
    """
    Backtest a betting strategy on historical match data.

    This simplified backtester iterates through each match, computes
    the expected value, determines a stake via fractional Kelly
    staking and updates the bankroll based on the actual result.
    Matches can be filtered by sport and risk settings will influence
    the stake sizes.  The function returns final bankroll, ROI and
    summary statistics.

    Parameters
    ----------
    df : DataFrame
        Historical matches including columns: match_id, kef, result
        (1 for win, 0 for lose).  Optional columns: prob, sport.
    sport : str, optional
        Filter matches to a specific sport.  If None, use all
        matches.
    risk_profile : str, default 'balanced'
        Risk profile controlling min EV threshold and other
        parameters.
    bank : float, default Config.BANKROLL
        Starting bankroll.
    use_provided_prob : bool, default False
        Use the 'prob' column if present instead of model
        predictions.
    verbose : bool, default False
        If True, prints a line per match with stake and bankroll.

    Returns
    -------
    dict
        A summary with final bank, ROI, total bets and hit rate.
    """
    # Filter by sport
    if sport is not None and "sport" in df.columns:
        df = df[df["sport"] == sport].copy()
    if df.empty:
        return {}

    # Ensure required columns
    if "result" not in df.columns or "kef" not in df.columns:
        raise ValueError("Historical data must include 'result' and 'kef' columns")

    # Predict probabilities if not provided
    if not use_provided_prob or "prob" not in df.columns:
        model = PredictionModel()
        # We'll train a very basic model on the entire dataset (not recommended in production)
        # For demonstration, we assume 'result' exists and other features
        # This will use built-in naive model; better models can be substituted
        try:
            model.train(df, target_col="result")
        except Exception:
            pass
        pred = model.predict_proba(df)
        df["prob"] = pred["prob"]
    else:
        df["prob"] = df["prob"].astype(float)

    df["value"] = df.apply(lambda r: compute_value(float(r["prob"]), float(r["kef"])), axis=1)

    risk_params = build_risk_params(risk_profile, sport)
    min_ev = float(risk_params.get("value_threshold", Config.VALUE_THRESHOLD))

    bankroll = float(bank)
    total_bets = 0
    wins = 0
    for _, row in df.iterrows():
        ev = row["value"]
        if ev < min_ev:
            continue
        prob = float(row["prob"])
        kef = float(row["kef"])
        # stake using fractional Kelly; volatility here simplified to EV std across dataset
        stake = kelly_fractional(prob, kef, bankroll, df["value"].std() if len(df) > 1 else 0)
        if stake <= 0:
            continue
        total_bets += 1
        outcome = int(row["result"])
        if outcome == 1:
            bankroll += stake * (kef - 1.0)
            wins += 1
        else:
            bankroll -= stake
        if verbose:
            print(f"Bet on {row['match_id']}: stake={stake:.2f}, result={outcome}, bank={bankroll:.2f}")
    if total_bets == 0:
        return {"final_bank": bankroll, "ROI": 0.0, "total_bets": 0, "hit_rate": 0.0}
    ROI = (bankroll - bank) / bank if bank != 0 else 0.0
    hit_rate = wins / total_bets if total_bets > 0 else 0.0
    return {
        "final_bank": bankroll,
        "ROI": ROI,
        "total_bets": total_bets,
        "hit_rate": hit_rate,
    }


def backtest_multi_strategy(
    df_history: pd.DataFrame,
    sport: str,
    strategies: List[Dict[str, Any]],
    bank_start: float = 10_000.0,
    use_provided_prob: bool = False,
    verbose: bool = False,
) -> Dict[str, Any]:
    """
    Backtest multiple betting strategies on the same historical data.

    This function simulates several risk/stake strategies over the same
    chronological match data.  Each strategy is defined by a risk
    profile and stake strategy.  The backtest iterates through each
    match once, updates a separate bankroll for each strategy and
    records performance metrics.

    Parameters
    ----------
    df_history : DataFrame
        Historical match data with at least 'match_id', 'kef', 'result'
        and optionally 'prob' and 'sport'.  It is assumed to be sorted
        chronologically (e.g. by date).
    sport : str
        Sport to filter the historical data for (e.g. 'football').
    strategies : list of dict
        Each dict must contain:
          - 'risk_profile': a valid risk profile name defined in Config
          - 'stake_strategy': one of 'kelly', 'percent', 'flat'
        Optionally a 'name' field to label the strategy.  If omitted
        the name will be derived from risk_profile and stake_strategy.
    bank_start : float, default 10000.0
        Starting bankroll for each strategy.
    use_provided_prob : bool, default False
        Whether to use probabilities from df_history or compute them.
    verbose : bool, default False
        If True, prints PnL per match per strategy.

    Returns
    -------
    dict
        A mapping of strategy names to their performance summary
        (final bank, total PnL, ROI, max drawdown, PnL series, bank series).
    """
    # Filter by sport
    if sport is not None and "sport" in df_history.columns:
        df_hist = df_history[df_history["sport"] == sport].copy()
    else:
        df_hist = df_history.copy()
    if df_hist.empty:
        return {}

    # Prepare probability column if needed
    if not use_provided_prob or "prob" not in df_hist.columns:
        model = PredictionModel()
        try:
            model.train(df_hist, target_col="result")
        except Exception:
            pass
        pred = model.predict_proba(df_hist)
        df_hist["prob"] = pred["prob"]
    else:
        df_hist["prob"] = df_hist["prob"].astype(float)

    df_hist["value"] = df_hist.apply(
        lambda r: compute_value(float(r["prob"]), float(r["kef"])), axis=1
    )

    # Prepare results structure
    results: Dict[str, Any] = {}
    for strat in strategies:
        name = strat.get("name") or f"{strat['risk_profile']}_{strat['stake_strategy']}"
        results[name] = {
            "bank_history": [],
            "pnl_history": [],
            "final_bank": bank_start,
            "total_pnl": 0.0,
            "roi": 0.0,
            "max_drawdown": 0.0,
        }

    # Iterate through matches in chronological order
    bank_dict = {(
        strat.get("name") or f"{strat['risk_profile']}_{strat['stake_strategy']}
    "): bank_start for strat in strategies}

    for _, row in df_hist.iterrows():
        # For volatility estimation we use value std; compute once here
        # Using full history std could leak info; but for simplicity we use current dataset
        vol = df_hist["value"].std() if len(df_hist) > 1 else 0.0
        for strat in strategies:
            strat_name = strat.get("name") or f"{strat['risk_profile']}_{strat['stake_strategy']}"
            bankroll = bank_dict[strat_name]
            # Build risk params
            risk_params = build_risk_params(strat["risk_profile"], sport)
            min_ev = float(risk_params.get("value_threshold", Config.VALUE_THRESHOLD))
            ev = row["value"]
            if ev < min_ev:
                # record no bet
                results[strat_name]["pnl_history"].append(0.0)
                results[strat_name]["bank_history"].append(bankroll)
                continue
            prob = float(row["prob"])
            kef = float(row["kef"])
            # compute stake based on strategy
            stake = 0.0
            stake_strategy = strat.get("stake_strategy", "kelly")
            if stake_strategy == "kelly":
                stake = kelly_fractional(prob, kef, bankroll, vol)
            elif stake_strategy == "percent":
                pct = float(risk_params.get("percent_stake", 0.05))
                stake = max(Config.MIN_STAKE, bankroll * pct)
            elif stake_strategy == "flat":
                flat = float(risk_params.get("flat_stake", Config.MIN_STAKE))
                stake = max(Config.MIN_STAKE, min(flat, bankroll * Config.MAX_BANK_FRACTION))
            else:
                stake = kelly_fractional(prob, kef, bankroll, vol)
            # ensure stake does not exceed bank fraction
            max_stake = bankroll * Config.MAX_BANK_FRACTION
            stake = max(Config.MIN_STAKE, min(stake, max_stake))
            if stake <= 0:
                results[strat_name]["pnl_history"].append(0.0)
                results[strat_name]["bank_history"].append(bankroll)
                continue
            # actual outcome
            outcome = int(row.get("result", 0))
            pnl = stake * (kef - 1.0) * outcome - stake * (1.0 - outcome)
            bankroll += pnl
            bank_dict[strat_name] = bankroll
            results[strat_name]["pnl_history"].append(pnl)
            results[strat_name]["bank_history"].append(bankroll)
    # Compute final metrics
    for strat in strategies:
        strat_name = strat.get("name") or f"{strat['risk_profile']}_{strat['stake_strategy']}"
        bank_hist = results[strat_name]["bank_history"]
        pnl_hist = results[strat_name]["pnl_history"]
        if not bank_hist:
            continue
        final_bank = bank_hist[-1]
        total_pnl = sum(pnl_hist)
        roi = (final_bank - bank_start) / bank_start if bank_start else 0.0
        # Compute max drawdown
        peak = -np.inf
        max_dd = 0.0
        for b in bank_hist:
            if b > peak:
                peak = b
            dd = peak - b
            if dd > max_dd:
                max_dd = dd
        results[strat_name].update(
            {
                "final_bank": float(final_bank),
                "total_pnl": float(total_pnl),
                "roi": float(roi),
                "max_drawdown": float(max_dd),
            }
        )
    return results