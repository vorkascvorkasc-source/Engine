"""
Machine learning models for outcome prediction.

This module defines a simple wrapper `PredictionModel` around scikit
learn components to predict match outcomes.  The intention is to make
model loading, training and inference explicit and easily
replaceable.  You can extend this class to integrate XGBoost,
CatBoost, LightGBM or neural networks without changing the rest of
the engine.
"""

from __future__ import annotations

from typing import Any, Dict

import numpy as np
import pandas as pd
from sklearn.calibration import IsotonicRegression
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import RobustScaler
from sklearn.model_selection import train_test_split

from .features import FeatureBuilder


class PredictionModel:
    """
    Flexible prediction model supporting multiple algorithms.

    This wrapper encapsulates a scaler, a base classifier and an optional
    calibrator to produce calibrated probabilities and uncertainty
    estimates.  The `backend` parameter controls which underlying
    algorithm is used.  Supported values are:

    - ``'logreg'``: logistic regression (default).
    - ``'xgb'``: XGBoost classifier (if available).
    - ``'lgb'``: LightGBM classifier (if available).
    - ``'cat'``: CatBoost classifier (if available).

    If the requested backend is unavailable, the model falls back to
    logistic regression.  You can extend this class to include
    additional models without changing the rest of the engine.
    """

    # Attempt to import optional ML backends.  These may not be
    # installed in all environments, so we wrap imports in try/except.
    try:
        from xgboost import XGBClassifier  # type: ignore
    except Exception:
        XGBClassifier = None  # type: ignore
    try:
        from lightgbm import LGBMClassifier  # type: ignore
    except Exception:
        LGBMClassifier = None  # type: ignore
    try:
        from catboost import CatBoostClassifier  # type: ignore
    except Exception:
        CatBoostClassifier = None  # type: ignore

    def __init__(self, backend: str = "logreg") -> None:
        # Selected backend; used when training
        self.backend = backend
        # Scaler is used for models that benefit from feature scaling
        self.scaler: RobustScaler | None = None
        # Base model instance; type depends on backend
        self.base_model: Any | None = None
        # Calibrator to adjust probabilities
        self.calibrator: IsotonicRegression | None = None
        # Flag to indicate training has completed
        self.trained: bool = False

    def _init_model(self) -> Any:
        """Instantiate the base model for the current backend."""
        if self.backend == "xgb" and self.XGBClassifier is not None:
            # Use a small number of estimators to avoid heavy training
            return self.XGBClassifier(n_estimators=300, max_depth=5, learning_rate=0.1, random_state=42)
        if self.backend == "lgb" and self.LGBMClassifier is not None:
            return self.LGBMClassifier(n_estimators=300, max_depth=-1, random_state=42, verbosity=-1)
        if self.backend == "cat" and self.CatBoostClassifier is not None:
            # CatBoost silent training
            return self.CatBoostClassifier(n_estimators=300, depth=6, learning_rate=0.1, random_state=42, verbose=0)
        # Fallback to logistic regression
        return LogisticRegression(max_iter=1000)

    def train(self, df: pd.DataFrame, target_col: str = "result") -> float:
        """Train the model using the specified backend.

        Parameters
        ----------
        df : DataFrame
            Training data including the target column.
        target_col : str, default 'result'
            Name of the target column; 1 for home win and 0 otherwise.

        Returns
        -------
        float
            Accuracy on a hold-out test set.
        """
        df = FeatureBuilder().build(df)
        # Extract numeric feature columns, excluding identifiers and target
        features = [
            c
            for c in df.columns
            if c not in ["match_id", "team_home", "team_away", target_col]
        ]
        X = df[features].values
        y = df[target_col].values

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )

        # Always scale features for linear models and as a safe default
        self.scaler = RobustScaler()
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)

        # Instantiate the appropriate base model
        model = self._init_model()
        # Fit the model.  CatBoost and XGBoost accept unscaled arrays;
        # other models benefit from scaling.  We use scaled data for
        # consistency.
        try:
            model.fit(X_train_scaled, y_train)
        except Exception:
            # If fitting fails, fallback to logistic regression
            model = LogisticRegression(max_iter=1000)
            model.fit(X_train_scaled, y_train)
        self.base_model = model

        # Compute raw predictions on the test set and calibrate
        probs_test = model.predict_proba(X_test_scaled)[:, 1]
        self.calibrator = IsotonicRegression(out_of_bounds="clip")
        self.calibrator.fit(probs_test, y_test)

        # Accuracy of the base model (not necessarily the final calibrator)
        try:
            acc = float(model.score(X_test_scaled, y_test))
        except Exception:
            acc = 0.0
        self.trained = True
        return acc

    def predict_proba(self, df: pd.DataFrame) -> Dict[str, np.ndarray]:
        """Predict probabilities and an uncertainty proxy.

        If the model is untrained, returns uniform probabilities and
        uncertainties.  Otherwise, applies scaling, model prediction
        and calibration.
        """
        if self.scaler is None or self.base_model is None or self.calibrator is None:
            n = len(df)
            return {
                "prob": np.full(n, 0.5, dtype=float),
                "uncertainty": np.full(n, 0.25, dtype=float),
            }
        df_fb = FeatureBuilder().build(df)
        features = [
            c
            for c in df_fb.columns
            if c not in ["match_id", "team_home", "team_away"]
        ]
        X = df_fb[features].values
        X_scaled = self.scaler.transform(X)
        # Some models may raise if not properly fit; catch gracefully
        try:
            raw_probs = self.base_model.predict_proba(X_scaled)[:, 1]
        except Exception:
            raw_probs = np.full(len(df), 0.5, dtype=float)
        calibrated = self.calibrator.transform(raw_probs)
        uncertainty = 1.0 - np.abs(calibrated - 0.5) * 2.0
        return {"prob": calibrated, "uncertainty": uncertainty}