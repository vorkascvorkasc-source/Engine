"""
Express (parlay) generation for the betting engine.

This module contains functions to construct multi-leg parlays (express
bets) using heuristics that balance expected value, confidence in
predictions and correlation penalties.  It is designed to work with
arbitrary lengths of parlays and supports weighting by risk profile.

The core function `generate_express` accepts a DataFrame of candidate
matches, a desired size and a risk parameter dictionary.  It
performs a random search to identify a combination of matches that
maximises a meta-score derived from EV and penalty terms.
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Tuple

import numpy as np
import pandas as pd

from .config import Config


def _express_base_metrics(combo_df: pd.DataFrame) -> Tuple[float, float, float]:
    """Compute combined probability, odds and EV of a parlay."""
    probs = combo_df["prob"].astype(float).values
    kefs = combo_df["kef"].astype(float).values
    if "value" in combo_df.columns:
        values = combo_df["value"].astype(float).values
    else:
        values = probs * (kefs - 1.0) - (1.0 - probs)
    total_prob = float(np.prod(probs))
    total_kef = float(np.prod(kefs))
    ev = float(np.prod(1.0 + values) - 1.0)
    return total_prob, total_kef, ev


def _express_conf_penalty(combo_df: pd.DataFrame) -> float:
    """
    Compute a penalty for low confidence legs.

    Higher confidence values (closer to 1) reduce the penalty.  If no
    confidence column is provided, a fallback based on proximity to
    prob=0.5 is used.  The returned value is in [0.5, 1.0].
    """
    if "confidence" in combo_df.columns:
        conf = combo_df["confidence"].astype(float).values
    else:
        probs = combo_df.get("prob", pd.Series(0.5, index=combo_df.index)).astype(
            float
        )
        conf = np.abs(probs.values - 0.5) * 2.0
    avg_conf = float(np.clip(conf.mean(), 0.0, 1.0))
    return 0.5 + 0.5 * avg_conf


def _express_corr_penalty(combo_df: pd.DataFrame) -> Tuple[float, int, int]:
    """
    Compute a penalty based on duplicated teams or leagues.

    The penalty starts at 1.0 and is multiplicatively reduced by 0.9
    for each duplicate team and by 0.95 for each duplicate league.
    Returns the penalty and the counts of duplicate teams and leagues.
    """
    teams: list[str] = []
    for _, r in combo_df.iterrows():
        teams.append(str(r.get("home_team", "")).strip())
        teams.append(str(r.get("away_team", "")).strip())
    teams = [t for t in teams if t]
    dup_teams = max(0, len(teams) - len(set(teams)))
    leagues = [str(r.get("league", "")).strip() for _, r in combo_df.iterrows()]
    leagues = [l for l in leagues if l]
    dup_leagues = max(0, len(leagues) - len(set(leagues)))
    penalty = 1.0
    if dup_teams > 0:
        penalty *= 0.9 ** dup_teams
    if dup_leagues > 0:
        penalty *= 0.95 ** dup_leagues
    return penalty, dup_teams, dup_leagues


def _is_valid_express_combo(combo_df: pd.DataFrame, size: int) -> bool:
    """
    Determine whether a candidate combination is valid.

    The combination is valid if it has the desired size, the match_ids
    are unique, there is at least one leg of rank S/A+/A/B, and the
    team names do not repeat.  This function can be customised to
    relax or tighten the rules governing express formation.
    """
    if len(combo_df) != size:
        return False
    if "match_id" in combo_df.columns:
        if combo_df["match_id"].nunique() != len(combo_df):
            return False
    if "rank" in combo_df.columns:
        if not combo_df["rank"].isin(["S", "A+", "A", "B"]).any():
            return False
    teams: list[str] = []
    for _, r in combo_df.iterrows():
        teams.append(str(r.get("home_team", "")).strip())
        teams.append(str(r.get("away_team", "")).strip())
    teams = [t for t in teams if t]
    if len(set(teams)) < len(teams):
        return False
    return True


def _express_meta_score(
    combo_df: pd.DataFrame,
    conf_weight: float,
    corr_weight: float,
) -> Tuple[float, float, float, float, float, float, int, int]:
    """
    Compute a meta-score that balances EV, confidence and anti-correlation.

    Returns a tuple of (meta_score, total_prob, total_kef, ev,
    avg_value, std_value, dup_teams, dup_leagues).
    """
    total_prob, total_kef, ev = _express_base_metrics(combo_df)
    if ev <= 0.0:
        return -1e9, total_prob, total_kef, ev, 0.0, 0.0, 0, 0
    conf_pen = _express_conf_penalty(combo_df)
    corr_pen, dup_teams, dup_leagues = _express_corr_penalty(combo_df)
    avg_val = float(combo_df["value"].mean()) if "value" in combo_df.columns else 0.0
    std_val = float(combo_df["value"].std()) if "value" in combo_df.columns else 0.0
    meta = ev * (conf_pen ** conf_weight) * (corr_pen ** corr_weight)
    return meta, total_prob, total_kef, ev, avg_val, std_val, dup_teams, dup_leagues


def generate_express(
    df: pd.DataFrame,
    size: int,
    risk_params: Dict[str, Any],
    rng: Optional[np.random.Generator] = None,
) -> Optional[Dict[str, Any]]:
    """
    Generate a multi-leg express bet with heuristics.

    Parameters
    ----------
    df : DataFrame
        Candidate matches including prob, value, rank, team names,
        league and confidence columns.
    size : int
        Desired number of legs in the parlay.
    risk_params : dict
        Risk parameters controlling EV threshold, weights and
        candidate selection.  See `Config` and `build_risk_params`.
    rng : numpy.random.Generator, optional
        Random number generator for reproducibility.

    Returns
    -------
    Optional[dict]
        A dictionary describing the best express found, or None if no
        suitable express could be constructed.
    """
    if df is None or df.empty or size < 2:
        return None
    candidate_multiplier = float(risk_params.get("candidate_multiplier", 1.0))
    max_candidates = int(max(5, min(Config.EXPRESS_MAX_CANDIDATES * candidate_multiplier, len(df))))
    candidates = df.nlargest(max_candidates, "value").copy()
    if len(candidates) < size:
        return None
    candidates = candidates.reset_index(drop=True)
    if rng is None:
        rng = np.random.default_rng()
    base_iters = 1500
    if size <= 3:
        max_iter = base_iters
    elif size <= 5:
        max_iter = base_iters * 2
    else:
        max_iter = base_iters * 3
    conf_w = float(risk_params.get("conf_weight", 1.0))
    corr_w = float(risk_params.get("corr_weight", 1.0))
    th = float(risk_params.get("value_threshold", Config.VALUE_THRESHOLD))
    best_combo: Optional[Dict[str, Any]] = None
    best_meta = -1e18
    n = len(candidates)
    for _ in range(max_iter):
        idx = rng.choice(n, size=size, replace=False)
        combo_df = candidates.loc[idx]
        if not _is_valid_express_combo(combo_df, size):
            continue
        (
            meta,
            total_prob,
            total_kef,
            ev,
            avg_val,
            std_val,
            dup_teams,
            dup_leagues,
        ) = _express_meta_score(combo_df, conf_w, corr_w)
        if ev <= th:
            continue
        if meta > best_meta:
            best_meta = float(meta)
            best_combo = {
                "kef": round(float(total_kef), 2),
                "prob": round(float(total_prob) * 100.0, 2),
                "ev": round(float(ev), 4),
                "meta_score": round(float(meta), 4),
                "size": size,
                "avg_value": round(avg_val, 4),
                "std_value": round(std_val, 4),
                "dup_teams": dup_teams,
                "dup_leagues": dup_leagues,
                "matches": [
                    f"{row.get('home_team', '?')} vs {row.get('away_team', '?')}"
                    for _, row in combo_df.iterrows()
                ],
                "legs": combo_df.to_dict("records"),
            }
    return best_combo


# ======================== SAME-GAME PARLAY ========================

def generate_same_game_express(
    df: pd.DataFrame,
    match_id_col: str = "match_id",
    max_legs: int = 3,
    min_ev: float = 0.03,
) -> Dict[str, Any]:
    """
    Construct a same‑game parlay (SGP) from markets on a single match.

    Given a DataFrame containing multiple markets for one match, this
    function selects up to `max_legs` markets with positive expected
    value and combines them into a parlay.  The DataFrame must
    include probability (`prob`), odds (`kef`) and value (`value`) or
    sufficient columns to compute value.  A minimum expected value
    threshold (`min_ev`) is applied to exclude weak markets.

    Parameters
    ----------
    df : DataFrame
        Markets for a single match.  Required columns are `prob`
        and `kef`, and optionally `value`.  Additional metadata
        columns (e.g. `market_type`, `description`) will be
        propagated to the output.
    match_id_col : str, default 'match_id'
        Column name identifying the match.  All rows must share
        the same match id.
    max_legs : int, default 3
        Maximum number of legs to include in the parlay.  The
        function will try to select up to this many markets with
        positive EV above `min_ev`.
    min_ev : float, default 0.03
        Minimum expected value threshold for each market.  Markets
        with EV below this value are ignored.

    Returns
    -------
    dict
        A dictionary describing the SGP with keys:
        - match_id: identifier of the match
        - legs: list of selected market dicts (market_type,
          description, prob, kef, value)
        - kef: combined decimal odds
        - prob: combined probability (0–1)
        - ev: expected value of the SGP
        - n_legs: number of legs in the parlay

        If no valid parlay can be constructed (e.g. fewer than two
        markets with positive EV), an empty dict is returned.
    """
    if df is None or df.empty:
        return {}
    # Ensure single match
    match_ids = df[match_id_col].unique()
    if len(match_ids) != 1:
        return {}
    # Work on a copy
    df_local = df.copy()
    # Compute value if missing
    if "value" not in df_local.columns:
        df_local["value"] = df_local.apply(
            lambda r: float(r["prob"]) * (float(r["kef"]) - 1.0)
            - (1.0 - float(r["prob"])),
            axis=1,
        )
    # Sort by value descending
    df_local = df_local.sort_values("value", ascending=False)
    legs: List[Dict[str, Any]] = []
    total_prob = 1.0
    total_kef = 1.0
    for _, row in df_local.iterrows():
        if len(legs) >= max_legs:
            break
        v = float(row["value"])
        if v < min_ev:
            continue
        p = float(row["prob"])
        k = float(row["kef"])
        legs.append(
            {
                "market_type": row.get("market_type", "unknown"),
                "description": row.get("description", ""),
                "prob": p,
                "kef": k,
                "value": v,
            }
        )
        total_prob *= p
        total_kef *= k
    # Need at least two legs to form a parlay
    if len(legs) < 2:
        return {}
    sgp_ev = total_prob * (total_kef - 1.0) - (1.0 - total_prob)
    return {
        "match_id": match_ids[0],
        "legs": legs,
        "kef": round(total_kef, 3),
        "prob": round(total_prob, 4),
        "ev": round(sgp_ev, 4),
        "n_legs": len(legs),
    }