"""
Risk-related utilities for the betting engine.

This package aggregates helpers for building risk parameters,
applying additional filters and advanced bankroll management.  The
submodules can be extended with new filters (e.g. limiting
exposure to certain leagues) and custom stake strategies.
"""

from .filters import limit_exposure, filter_by_time_window

__all__ = ["limit_exposure", "filter_by_time_window"]