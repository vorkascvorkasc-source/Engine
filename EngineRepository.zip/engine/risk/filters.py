"""
Advanced risk filters for match selection.

This module provides additional filters that can be applied to a
DataFrame of candidate matches before computing singles or expresses.
The filters can limit exposure to certain leagues, teams or date
ranges to manage bankroll risk or reduce correlation.

All functions in this module accept and return DataFrames, allowing
them to be chained together.  They can be used optionally from
client code before calling `medium_calculate`.
"""

from __future__ import annotations

import pandas as pd
from datetime import datetime, timedelta


def limit_exposure(df: pd.DataFrame, column: str, limit: int) -> pd.DataFrame:
    """
    Limit the number of matches per unique value in a given column.

    For example, to avoid overexposure to a single team, you can call
    `limit_exposure(df, column="home_team", limit=2)` which will
    retain at most two matches per home team.  If the column is not
    present, the DataFrame is returned unchanged.

    Parameters
    ----------
    df : DataFrame
        Candidate matches.
    column : str
        Column on which to apply the exposure limit.
    limit : int
        Maximum number of rows to retain per unique value in the
        column.

    Returns
    -------
    DataFrame
        Filtered DataFrame with exposure limited.
    """
    if column not in df.columns:
        return df
    # group and take first `limit` entries per group
    return df.groupby(column).head(limit).reset_index(drop=True)


def filter_by_time_window(
    df: pd.DataFrame,
    date_col: str,
    start_date: datetime,
    end_date: datetime,
) -> pd.DataFrame:
    """
    Filter matches to a given date window.

    This can be used to avoid matches that are too soon (e.g. to
    exclude live or imminent games) or too far away (where odds
    movement might be unstable).  The function requires that the
    specified `date_col` is present and parseable as datetime.

    Parameters
    ----------
    df : DataFrame
        Candidate matches with a date column.
    date_col : str
        Name of the date column (e.g. 'match_date').
    start_date : datetime
        Lower bound (inclusive).
    end_date : datetime
        Upper bound (inclusive).

    Returns
    -------
    DataFrame
        Filtered DataFrame containing matches within the window.
    """
    if date_col not in df.columns:
        return df
    dts = pd.to_datetime(df[date_col], errors="coerce")
    mask = (dts >= start_date) & (dts <= end_date)
    return df[mask].copy().reset_index(drop=True)