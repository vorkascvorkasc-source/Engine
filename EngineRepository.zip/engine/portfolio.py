"""
Portfolio simulation utilities for the betting engine.

This module provides a Monte‑Carlo simulation to estimate the
distribution of returns for a set of bets.  It can be used to
evaluate bankroll volatility, expected profit and risk of drawdown
given a specific stake strategy.
"""

from __future__ import annotations

from typing import Dict, Any, Optional

import numpy as np
import pandas as pd


def simulate_portfolio(
    matches: pd.DataFrame,
    iterations: int = 1000,
    stake_strategy: str = "fixed",
    rng: Optional[np.random.Generator] = None,
) -> Dict[str, Any]:
    """
    Simulate the portfolio profit/loss distribution over many trials.

    Given a DataFrame of bets with columns prob, kef and stake, this
    function draws binary outcomes using the provided probabilities
    and computes the resulting profit or loss.  It returns various
    statistics including mean, standard deviation, 5th and 95th
    percentiles and an estimate of worst drawdown.

    Parameters
    ----------
    matches : DataFrame
        A table of bets with at least columns prob, kef and stake.
    iterations : int, optional
        Number of Monte‑Carlo runs.  Defaults to 1000.
    stake_strategy : str, optional
        The stake mode: 'fixed' uses the provided stake column, any
        other value uses a unit stake for all bets.  Defaults to
        'fixed'.
    rng : numpy.random.Generator, optional
        Random generator for reproducibility.

    Returns
    -------
    dict
        Summary statistics of the simulation.
    """
    if matches is None or matches.empty:
        return {}
    required = {"prob", "kef", "stake"}
    if not required.issubset(matches.columns):
        return {}
    probs = matches["prob"].astype(float).values
    kefs = matches["kef"].astype(float).values
    if stake_strategy == "fixed":
        stakes = matches["stake"].astype(float).values
    else:
        stakes = np.ones_like(probs)
    if rng is None:
        rng = np.random.default_rng()
    results = []
    for _ in range(iterations):
        outcomes = rng.binomial(1, probs)
        pnl = np.sum(stakes * ((kefs - 1.0) * outcomes - (1 - outcomes)))
        results.append(pnl)
    arr = np.array(results)
    mean = float(arr.mean())
    std = float(arr.std(ddof=1))
    p5 = float(np.percentile(arr, 5))
    p95 = float(np.percentile(arr, 95))
    seq_outcomes = []
    for _ in range(200):
        outcomes = rng.binomial(1, probs)
        pnl_seq = np.cumsum(stakes * ((kefs - 1.0) * outcomes - (1 - outcomes)))
        seq_outcomes.append(np.min(pnl_seq))
    worst_drawdown = float(np.percentile(seq_outcomes, 5))
    return {
        "mean": mean,
        "std": std,
        "p5": p5,
        "p95": p95,
        "worst_drawdown_est": worst_drawdown,
        "sim_iterations": iterations,
    }