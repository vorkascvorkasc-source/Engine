"""
Professional capper integration for the betting engine.

This module defines the `CapperHandler` class which manages a store
of professional capper notes and estimates.  It can aggregate
opinions per match, compute reliability weights for each capper
based on historical ROI and filter out untrustworthy sources.

Capper opinions are stored in a JSON file (`Config.CAPPERS_FILE`) and
persisted across sessions.  Use `aggregate_match_features` to
retrieve a combined signal and expected value for a given match.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from .config import Config
from .utils import load_json, save_json


@dataclass
class CapperNote:
    match_id: str
    capper: str
    text: str
    ev_estimate: Optional[float]
    ts: str
    result: Optional[int] = None  # 1 for win, 0 for loss


class CapperHandler:
    """
    Handle storage and analysis of professional capper opinions.

    Capper notes include a match identifier, the capper's name,
    optionally an EV estimate and a timestamp.  The handler can
    compute reliability weights for each capper and aggregate their
    signals to aid the model's value estimates.
    """

    def __init__(self, file: str = Config.CAPPERS_FILE) -> None:
        self.file = Path(file)
        raw: List[Dict[str, Any]] = load_json(self.file, [])
        self.cappers: List[Dict[str, Any]] = raw

    def _persist(self) -> None:
        save_json(self.file, self.cappers)

    def add(
        self,
        match_id: str,
        capper_name: str,
        text: str,
        ev_estimate: Optional[float] = None,
        result: Optional[int] = None,
    ) -> None:
        """Add a new capper note and persist the change."""
        self.cappers.append(
            {
                "match_id": match_id,
                "capper": capper_name,
                "text": text,
                "ev_estimate": ev_estimate,
                "ts": datetime.utcnow().isoformat(),
                "result": result,
            }
        )
        self._persist()

    def get_notes(self, match_id: str) -> List[Dict[str, Any]]:
        """Return all notes for a particular match."""
        return [c for c in self.cappers if c.get("match_id") == match_id]

    def compute_capper_weights(self) -> Dict[str, float]:
        """
        Compute reliability weights for cappers based on historical EV and results.

        Cappers with poor historical ROI or little data receive low
        weight.  Negative ROI cappers with sufficiently many notes
        may be dropped entirely.
        """
        if not self.cappers:
            return {}

        df = pd.DataFrame(self.cappers)
        if "ev_estimate" not in df.columns:
            return {}

        def _agg(group: pd.DataFrame) -> pd.Series:
            evs = group["ev_estimate"].dropna().values
            mean_ev = float(np.mean(evs)) if len(evs) else 0.0
            count = len(group)
            if "result" in group.columns and group["result"].notna().any():
                res = group["result"].fillna(0).astype(float).values
                if len(evs) == len(res):
                    roi_proxy = float(np.mean(evs * res))
                else:
                    roi_proxy = 0.0
            else:
                roi_proxy = 0.0
            return pd.Series({"mean_ev": mean_ev, "roi_proxy": roi_proxy, "count": count})

        summary = df.groupby("capper").apply(_agg)
        if summary.empty:
            return {}

        weights: Dict[str, float] = {}
        max_abs_roi = float(summary["roi_proxy"].abs().max()) or 1.0
        for capper, row in summary.iterrows():
            cnt = row["count"]
            mean_ev = row["mean_ev"]
            roi_proxy = row["roi_proxy"]

            if cnt < 10:
                w = 0.1
            else:
                w = float(roi_proxy) / max_abs_roi

            # Discard persistently negative cappers
            if cnt >= 20 and roi_proxy < 0 and mean_ev <= 0:
                w = 0.0

            weights[capper] = max(0.0, float(w))

        max_w = max(weights.values()) if weights else 1.0
        if max_w > 0:
            weights = {k: v / max_w for k, v in weights.items()}
        return weights

    def aggregate_match_features(self, match_id: str) -> Dict[str, float]:
        """
        Aggregate capper signals for a match.

        Returns a dict with:
        - pro_signal: weighted count of opinions
        - pro_ev: weighted average EV across cappers
        If no opinions exist for the match, pro_signal is the number
        of notes and pro_ev defaults to 0.
        """
        notes = self.get_notes(match_id)
        if not notes:
            return {"pro_signal": 0.0, "pro_ev": 0.0}

        weights = self.compute_capper_weights()
        evs: List[float] = []
        eff_weights: List[float] = []

        for n in notes:
            capper = n.get("capper")
            ev = n.get("ev_estimate")
            if ev is None or capper not in weights:
                continue
            w = weights[capper]
            if w <= 0:
                continue
            evs.append(float(ev))
            eff_weights.append(float(w))

        if not evs:
            return {"pro_signal": float(len(notes)), "pro_ev": 0.0}

        pro_ev = float(np.average(np.array(evs, dtype=float), weights=np.array(eff_weights)))
        pro_signal = float(sum(eff_weights))
        return {"pro_signal": pro_signal, "pro_ev": pro_ev}

    # ---------------------------------------------------------------------
    # New functionality: sport-specific capper weights
    #
    # In some sports, a capper may be more reliable than in others.
    # The following methods allow computation of weights per sport and
    # retrieval of a capper's weight for a particular sport.

    def compute_weights_by_sport(self, lookback_days: int = 365) -> Dict[str, Dict[str, float]]:
        """
        Compute capper reliability weights separately for each sport.

        Returns a nested dict where the first level keys are sport names
        (or 'unknown' if not provided) and the values are dictionaries
        mapping capper names to normalized reliability weights (0..1).

        Parameters
        ----------
        lookback_days : int, optional
            Only consider capper notes within this many days from now.

        Notes
        -----
        The method groups capper notes by the 'sport' field and
        computes an average EV per capper.  If result data exists,
        it uses mean EV as a proxy for ROI.  Cappers with more data
        and higher EV get higher weights.  If no EV estimates are
        available, weights fall back to normalized counts of notes per
        capper.  Persistent negative or low-EV cappers may be downweighted.
        """
        df = pd.DataFrame(self.cappers)
        if df.empty:
            return {}

        # Convert timestamp to datetime and filter by lookback
        if "ts" in df.columns:
            df["ts"] = pd.to_datetime(df["ts"], errors="coerce")
            cutoff = pd.Timestamp.utcnow() - pd.Timedelta(days=lookback_days)
            df = df[df["ts"] >= cutoff]

        if df.empty:
            return {}

        # Ensure sport column exists
        sport_col = df.get("sport")
        if sport_col is None:
            df["sport"] = "unknown"
        else:
            df["sport"] = sport_col.fillna("unknown")

        weights_by_sport: Dict[str, Dict[str, float]] = {}

        # Group by sport and compute weights
        for sport, d_sport in df.groupby("sport"):
            if d_sport.empty:
                continue
            # Compute mean EV per capper as proxy for ROI
            if "ev_estimate" in d_sport.columns:
                summary = d_sport.groupby("capper").agg(
                    mean_ev=("ev_estimate", "mean"),
                    count=("ev_estimate", "count"),
                )
                max_ev = summary["mean_ev"].replace(0, np.nan).max()
                # Normalize weights by max EV; if max_ev <= 0, all weights are 0
                if pd.isna(max_ev) or max_ev <= 0:
                    sport_weights = {c: 0.0 for c in summary.index}
                else:
                    sport_weights = {c: float(v / max_ev) for c, v in summary["mean_ev"].items()}
            else:
                # Fallback: weight by counts
                counts = d_sport["capper"].value_counts()
                max_count = counts.max() if len(counts) > 0 else 0
                sport_weights = {
                    capper: float(cnt / max_count) if max_count > 0 else 0.0
                    for capper, cnt in counts.items()
                }
            # Normalize weights to [0,1]
            max_w = max(sport_weights.values()) if sport_weights else 1.0
            if max_w > 0:
                sport_weights = {k: v / max_w for k, v in sport_weights.items()}
            weights_by_sport[sport] = sport_weights

        return weights_by_sport

    def get_capper_weight(
        self,
        capper_name: str,
        sport: str,
        weights_by_sport: Optional[Dict[str, Dict[str, float]]] = None,
    ) -> float:
        """
        Retrieve the weight for a capper for a specific sport.

        If `weights_by_sport` is not provided, it will compute weights
        using the default lookback period.  If the capper or sport
        is not present, returns 0.0.
        """
        if weights_by_sport is None:
            weights_by_sport = self.compute_weights_by_sport()
        sport_weights = weights_by_sport.get(sport, {})
        return float(sport_weights.get(capper_name, 0.0))


# Global capper handler instance
capper_handler = CapperHandler()