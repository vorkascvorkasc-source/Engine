"""
Data fetching subpackage for the betting engine.

This package contains utilities for downloading match data from
different sources.  The HTTP fetcher can scrape or call APIs to
retrieve upcoming fixtures, while the historical loader reads data
files for backtesting.  These modules should be extended with
real implementations appropriate for your data providers.
"""

from .http_fetcher import fetch_matches
from .history_loader import load_historical_data

__all__ = ["fetch_matches", "load_historical_data"]