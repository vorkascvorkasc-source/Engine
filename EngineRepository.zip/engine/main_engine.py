"""
Main engine entry point for singles and express selection.

This module ties together models, capper opinions, risk profiles and
express generation to produce recommended singles and parlays.  It
exposes a single function `medium_calculate` that accepts a DataFrame
with candidate matches and returns a structured result including
singles, expresses, aggregate stake and expected profit.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

from .config import Config, build_risk_params
from .utils import (
    kelly_fractional,
    compute_value,
    implied_prob_from_odds,
)
from .ml import PredictionModel
from .cappers import capper_handler
from .express import generate_express
from .risk.filters import limit_exposure, filter_by_time_window
from datetime import datetime


def _assign_ranks(df: pd.DataFrame) -> pd.DataFrame:
    """
    Assign rank labels (S, A+, A, B, C) to each match based on
    probability and value.

    The DataFrame is modified in place and also returned for chaining.
    Only matches with prob/value above configured thresholds receive
    high ranks.  All others default to rank 'C'.
    """
    df["rank"] = "C"
    rank_order = ["S", "A+", "A", "B"]
    for rk in rank_order:
        thresh = Config.PRIORITY_THRESHOLDS[rk]
        mask = (df["prob"] >= thresh["prob"]) & (df["value"] >= thresh["value"])
        df.loc[mask & (df["rank"] == "C"), "rank"] = rk
    return df


def medium_calculate(
    df: Optional[pd.DataFrame] = None,
    fetch_online: bool = False,
    sport: Optional[str] = None,
    bank: float = Config.BANKROLL,
    *,
    express_min_size: Optional[int] = None,
    express_max_size: Optional[int] = None,
    risk_profile: str = "balanced",
    value_threshold: Optional[float] = None,
    separate_express: bool = True,
    use_provided_prob: bool = False,
    # --- advanced filtering parameters ---
    exposure_limits: Optional[Dict[str, int]] = None,
    date_range: Optional[tuple[datetime | str, datetime | str]] = None,
    date_col: str = "match_date",
    max_uncertainty: Optional[float] = None,
    rng: Optional[np.random.Generator] = None,
    stake_strategy: Optional[str] = None,
    ml_backend: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Build singles and express recommendations from raw match data.

    This is the high-level function that orchestrates loading match
    data, integrating capper opinions, predicting probabilities,
    computing value, assigning ranks, selecting singles and
    constructing expresses.

    Parameters
    ----------
    df : DataFrame, optional
        Candidate match data.  Must include match_id, home_team, away_team
        and kef.  Additional fields like prob, sport, league, ranks
        enhance the results.
    fetch_online : bool, default False
        If True and df is None, a placeholder for online fetching could
        be inserted here.  Currently not implemented.
    sport : str, optional
        If provided, filters matches to the given sport.  This can
        improve risk parameter selection and model applicability.
    bank : float, default Config.BANKROLL
        Bankroll used for stake calculation.
    express_min_size : int, optional
        Minimum size of express bets.  Defaults to risk profile settings.
    express_max_size : int, optional
        Maximum size of express bets.  Defaults to risk profile settings.
    risk_profile : str, default 'balanced'
        One of 'conservative', 'balanced', 'aggressive'.  Controls EV
        thresholds, parlay sizes and penalty weights.
    value_threshold : float, optional
        Override threshold for minimum EV on singles and expresses.  If
        None, uses the risk profile and sport adjustments.
    separate_express : bool, default True
        If True, selects candidates for expresses independently of
        singles.  If False, uses only the singles as express legs.
    use_provided_prob : bool, default False
        If True and df contains a 'prob' column, uses that as the
        probability estimate instead of the internal model.
    rng : numpy.random.Generator, optional
        Random generator for reproducible express generation.

    Additional Parameters
    ---------------------
    exposure_limits : dict[str, int], optional
        Limits exposure per unique value in a given column.  For example,
        ``{"home_team": 2, "away_team": 2}`` ensures that at most two
        matches per team appear in the candidate set.  This can help
        diversify singles and parlay legs to manage bankroll risk.
    date_range : tuple[datetime | str, datetime | str], optional
        Tuple of (start_date, end_date) defining an inclusive time
        window in which matches must fall.  Dates can be provided as
        ``datetime`` objects or ISO strings (YYYY-MM-DD).  Matches
        outside the window are dropped.  This is useful to avoid
        imminent games or those too far in the future where odds are
        unstable.
    date_col : str, default "match_date"
        Name of the column in ``df`` containing match datetime
        information.  If ``date_range`` is provided, this column is
        parsed and filtered accordingly.  If absent, the filter is
        skipped.

    max_uncertainty : float, optional
        Discard matches with model uncertainty exceeding this
        threshold.  Uncertainty is computed as ``1 - |prob - 0.5| * 2``,
        so values range from 0 (very certain) to 1 (completely
        uncertain).  Filtering high-uncertainty matches can improve
        reliability at the cost of reducing the candidate pool.

    stake_strategy : str, optional
        Override the default staking strategy defined in the risk
        profile.  Valid values are:

        - ``'kelly'`` (default): Fractional Kelly based on prob, odds
          and the value standard deviation.  Stakes are capped by
          ``Config.MAX_BANK_FRACTION`` and respect ``Config.MIN_STAKE``.
        - ``'percent'``: Bet a fixed percentage of the bankroll on
          each match.  The exact percentage is defined by
          ``risk_params['percent_stake']``.
        - ``'flat'``: Bet a fixed amount on every match, given by
          ``risk_params['flat_stake']``.  Bets are still capped by
          ``Config.MAX_BANK_FRACTION`` and must exceed
          ``Config.MIN_STAKE`` to be placed.

        If ``None`` (the default), the strategy from the selected
        risk profile is used.  You can fine-tune this behaviour in
        the risk profiles (see ``engine/config.py``).

    ml_backend : str, optional
        Specify which machine-learning backend to use for probability
        predictions.  Supported values are ``'logreg'``, ``'xgb'``,
        ``'lgb'``, ``'cat'``.  If ``None`` (the default), the
        backend defined in the selected risk profile is used.  See
        ``PredictionModel`` in ``engine/ml.py`` for details.

    Returns
    -------
    dict
        A dictionary with keys: ``singles`` (list of dicts),
        ``expresses`` (dict keyed by size), ``total_stake``,
        ``expected_profit`` and ``top_count`` (number of high-rank
        singles).  Additional keys may be added in future versions.
    """
    if df is None:
        if not fetch_online:
            return {}
        # Placeholder: add your online fetcher here
        return {}

    df = df.copy()
    df["match_id"] = df["match_id"].astype(str)
    # Ensure rank columns are numeric; if missing, use default 99 for all
    if "home_rank" in df.columns:
        df["home_rank"] = pd.to_numeric(df["home_rank"], errors="coerce").fillna(99)
    else:
        df["home_rank"] = 99
    if "away_rank" in df.columns:
        df["away_rank"] = pd.to_numeric(df["away_rank"], errors="coerce").fillna(99)
    else:
        df["away_rank"] = 99
    if sport is not None and "sport" in df.columns:
        df = df[df["sport"] == sport].copy()
        if df.empty:
            return {}

    # -------------------------------------------------------------------
    # Determine risk parameters early so they can influence exposure and
    # subsequent filtering.  Risk profiles are merged with sport-specific
    # adjustments via ``build_risk_params``.  This call happens only
    # once; risk_params is reused throughout this function.
    risk_params = build_risk_params(risk_profile, sport)

    # Apply exposure limits per column (if any).  This step reduces
    # over-concentration on individual teams or leagues before any
    # modelling occurs.  If explicit limits are not provided, fetch
    # defaults from Config based on the risk profile.  We apply
    # ``limit_exposure`` sequentially for each specified column.
    if exposure_limits is None:
        exposure_limits = Config.EXPOSURE_LIMITS.get(risk_profile, {})
    if exposure_limits:
        for col, limit in exposure_limits.items():
            try:
                df = limit_exposure(df, column=col, limit=int(limit))
            except Exception:
                # silently ignore invalid columns or limits
                pass

    # Apply date window filter (if specified)
    if date_range:
        try:
            start_raw, end_raw = date_range
            # Convert to datetime if needed
            if isinstance(start_raw, str):
                start_dt = datetime.fromisoformat(start_raw)
            else:
                start_dt = start_raw
            if isinstance(end_raw, str):
                end_dt = datetime.fromisoformat(end_raw)
            else:
                end_dt = end_raw
            df = filter_by_time_window(df, date_col=date_col, start_date=start_dt, end_date=end_dt)
        except Exception:
            # If parsing fails or column missing, ignore silently
            pass

    # Aggregate capper opinions
    pro_signals = []
    pro_evs = []
    for mid in df["match_id"]:
        feats = capper_handler.aggregate_match_features(mid)
        pro_signals.append(feats["pro_signal"])
        pro_evs.append(feats["pro_ev"])
    df["pro_signal"] = pro_signals
    df["pro_ev"] = pro_evs

    # Top match flag
    df["is_top_match"] = (
        (df["home_rank"] <= 6) & (df["away_rank"] >= 12)
    ) | ((df["home_rank"] <= 4) & (df["away_rank"] >= 15))

    feature_cols = ["is_top_match", "pro_signal", "pro_ev", "home_rank", "away_rank"]
    X = df[feature_cols].fillna(0)

    # Predict probabilities
    # Determine which ML backend to use.  Explicit ml_backend
    # parameter overrides the risk profile setting.  If none is
    # specified, use the value from risk_params (default 'logreg').
    backend = ml_backend or risk_params.get("ml_backend", "logreg")

    if use_provided_prob and "prob" in df.columns:
        probs = df["prob"].astype(float).values
        df["prob"] = probs
        df["uncertainty"] = 1.0 - np.abs(probs - 0.5) * 2.0
        df["confidence"] = 1.0 - df["uncertainty"]
    else:
        # Instantiate prediction model with selected backend
        model = PredictionModel(backend=backend)
        pred = model.predict_proba(X)
        df["prob"] = pred["prob"]
        df["uncertainty"] = pred["uncertainty"]
        df["confidence"] = 1.0 - df["uncertainty"]

    # Filter out matches exceeding maximum uncertainty threshold
    if max_uncertainty is not None:
        try:
            threshold = float(max_uncertainty)
        except Exception:
            threshold = None
        if threshold is not None:
            df = df[df["uncertainty"] <= threshold].copy()
            if df.empty:
                return {}

    # Filter by odds range
    df["kef"] = pd.to_numeric(df["kef"], errors="coerce")
    df = df[(df["kef"] >= Config.KEF_MIN) & (df["kef"] <= Config.KEF_MAX)].copy()
    if df.empty:
        return {}

    # Compute expected value
    df["value"] = df.apply(lambda r: compute_value(float(r["prob"]), float(r["kef"])), axis=1)

    # -------------------------------------------------------------------
    # Apply sport-specific exposure limits after value calculation.
    # risk_params may include a dictionary mapping sport names to the
    # maximum number of matches to retain for that sport.  We sort by
    # descending EV so that only the highest-value matches are kept.
    sport_limits = risk_params.get("sport_exposure_limits", None)
    if sport_limits and "sport" in df.columns:
        try:
            df_sorted = df.sort_values("value", ascending=False).copy()
            selected_rows = []
            for sport_name, limit in sport_limits.items():
                sub = df_sorted[df_sorted["sport"] == sport_name].copy()
                if not sub.empty:
                    limit_int = int(limit)
                    selected_rows.append(sub.head(limit_int))
            # Include other sports not specified in sport_limits without restriction
            other_sports = set(df_sorted["sport"].unique()) - set(sport_limits.keys())
            for other in other_sports:
                sub = df_sorted[df_sorted["sport"] == other].copy()
                selected_rows.append(sub)
            if selected_rows:
                df = pd.concat(selected_rows, ignore_index=True)
        except Exception:
            pass

    # Risk parameters
    risk_params = build_risk_params(risk_profile, sport)
    base_v = df["value"].copy()
    cap_weight = float(risk_params.get("capper_ev_weight", 0.0))
    noise_thr = risk_params.get("capper_noise_threshold", None)
    if cap_weight and "pro_ev" in df.columns:
        cap_v = df["pro_ev"].astype(float)
        if noise_thr:
            diff_ratio = (cap_v - base_v).abs() / (base_v.abs() + 1e-6)
            cap_adj = cap_v.where(diff_ratio <= noise_thr, 0.0)
        else:
            cap_adj = cap_v
        df["value"] = base_v + cap_weight * cap_adj

    # Assign ranks
    df = _assign_ranks(df)

    # Minimum value threshold.  Use risk profile default if not provided.
    if value_threshold is None:
        value_threshold = float(risk_params.get("value_threshold", Config.VALUE_THRESHOLD))

    # Dynamically adjust value threshold based on variance of value.
    # This helps reduce risk when value distribution is volatile.  A
    # positive ev_scale_factor increases the threshold by a factor of
    # the standard deviation of value across all candidates.
    ev_scale = float(risk_params.get("ev_scale_factor", 0.0))
    if ev_scale and not df["value"].empty:
        try:
            std_all = float(df["value"].std())
        except Exception:
            std_all = 0.0
        # Only increase the threshold; do not lower it below the base
        if std_all > 0:
            value_threshold = max(value_threshold, value_threshold + ev_scale * std_all)

    # Build singles
    df_singles = df[df["value"] >= value_threshold].copy()
    singles_result: list[Dict[str, Any]] = []
    if not df_singles.empty:
        # Determine staking strategy: explicit parameter overrides risk profile
        strategy = stake_strategy or risk_params.get("stake_strategy", "kelly")
        # compute standard deviation of values once for kelly
        std_val = float(df_singles["value"].std()) if len(df_singles) > 1 else 0.0
        # Prepare stake array with rank-based weighting.  Each stake
        # starts with the selected staking strategy (kelly, percent or flat).
        # After computing the base stake, apply the rank weight from
        # risk_params['rank_weights'] so that higher-ranked matches
        # receive proportionally larger bets.  Then cap the stake by
        # Config.MAX_BANK_FRACTION and enforce the minimum stake.
        stakes = []
        # Retrieve rank weights once; default to 1.0 if not defined
        rank_weights: Dict[str, float] = risk_params.get("rank_weights", {})
        # capture current value threshold for EV weighting
        local_threshold = float(value_threshold)
        ev_factor = float(risk_params.get("ev_weight_factor", 0.0))
        for _, row in df_singles.iterrows():
            prob = float(row["prob"])
            odds = float(row["kef"])
            # compute base stake based on strategy
            if strategy == "percent":
                pct = float(risk_params.get("percent_stake", 0.01))
                base_stake = bank * pct
            elif strategy == "flat":
                base_stake = float(risk_params.get("flat_stake", Config.MIN_STAKE))
            else:  # default to kelly fractional
                base_stake = kelly_fractional(prob, odds, bank, std_val)
            # apply rank weight
            rk = row.get("rank", "C")
            weight = float(rank_weights.get(rk, 1.0))
            stake = base_stake * weight
            # apply EV-based scaling: increase stake for high EV picks.
            if ev_factor > 0.0:
                try:
                    val = float(row.get("value", 0.0))
                    # ratio of how far value exceeds threshold; below 0 -> 0
                    ratio = (val - local_threshold) / abs(local_threshold) if local_threshold != 0 else 0.0
                    if ratio < 0:
                        ratio = 0.0
                    stake = stake * (1.0 + ev_factor * ratio)
                except Exception:
                    pass
            # Enforce max fraction of bankroll
            max_stake = bank * Config.MAX_BANK_FRACTION
            stake = min(float(stake), float(max_stake))
            # Ensure minimum stake threshold
            if stake < Config.MIN_STAKE:
                stake = 0.0
            stakes.append(stake)
        df_singles["stake"] = stakes
        # drop zero-stake bets
        df_singles = df_singles[df_singles["stake"] > 0]
        # Additional metrics
        df_singles["implied_prob"] = df_singles["kef"].apply(implied_prob_from_odds)
        df_singles["edge"] = df_singles["prob"] - df_singles["implied_prob"]
        total_bank = float(bank)
        # After computing initial stakes, enforce daily staking cap.
        # If the sum of all stakes exceeds bank * daily_stake_cap, scale
        # down proportionally.  This helps control overall risk for the
        # day.  After scaling, drop bets falling below Config.MIN_STAKE.
        daily_cap = risk_params.get("daily_stake_cap", None)
        try:
            cap_val = float(daily_cap) if daily_cap is not None else None
        except Exception:
            cap_val = None
        if cap_val and cap_val > 0:
            max_total = bank * cap_val
            total_stakes = float(df_singles["stake"].sum())
            if total_stakes > max_total and total_stakes > 0:
                scale = max_total / total_stakes
                # scale stakes
                df_singles["stake"] = df_singles["stake"] * scale
                # drop bets below MIN_STAKE after scaling
                df_singles = df_singles[df_singles["stake"] >= Config.MIN_STAKE]
                # Recompute stake_fraction after scaling
                total_stakes = float(df_singles["stake"].sum())

        # -------------------------------------------------------------------
        # Apply league limit if specified.  To avoid overexposure to a
        # particular league, only keep the top N matches by value for
        # each league.  The limit is defined in the risk profile via
        # ``league_limit``.  If the limit is None or not positive,
        # skip this filter.  If there is no 'league' column, this
        # filter is silently ignored.  Sorting by descending value
        # ensures the highest EV matches are retained.
        league_lim = risk_params.get("league_limit", None)
        try:
            # convert to positive integer
            league_lim_int = int(league_lim) if league_lim is not None else None
        except Exception:
            league_lim_int = None
        if league_lim_int and league_lim_int > 0 and "league" in df_singles.columns:
            try:
                df_singles = df_singles.sort_values("value", ascending=False)
                df_singles = (
                    df_singles.groupby("league", group_keys=False)
                    .head(league_lim_int)
                    .reset_index(drop=True)
                )
            except Exception:
                pass

        df_singles["stake_fraction"] = df_singles["stake"] / total_bank
        df_singles = df_singles.sort_values(
            ["rank", "value"], ascending=[True, False]
        )
        singles_result = df_singles.to_dict("records")

    # Build expresses
    expresses: Dict[str, Dict[str, Any]] = {}
    if separate_express:
        df_express = df.copy()
    else:
        df_express = df_singles.copy()
    df_express = df_express[df_express["value"] >= min(value_threshold, Config.VALUE_THRESHOLD)].copy()
    if not df_express.empty:
        rp_min = int(risk_params.get("min_size", 3))
        rp_max = int(risk_params.get("max_size", Config.EXPRESS_DEFAULT_MAX_SIZE))
        if express_min_size is None:
            express_min_size = rp_min
        if express_max_size is None:
            express_max_size = rp_max
        express_min_size = max(2, int(express_min_size))
        express_max_size = min(int(express_max_size), Config.EXPRESS_DEFAULT_MAX_SIZE)
        express_max_size = max(express_max_size, express_min_size)
        if rng is None:
            rng = np.random.default_rng()
        for size in range(express_min_size, express_max_size + 1):
            if size > len(df_express):
                break
            expr = generate_express(df_express, size, risk_params, rng)
            if expr:
                expresses[f"exp{size}"] = expr

    total_stake = float(df_singles["stake"].sum()) if not df_singles.empty else 0.0
    expected_profit = (
        float((df_singles["stake"] * df_singles["value"]).sum())
        if not df_singles.empty
        else 0.0
    )
    top_count = int(df_singles["rank"].isin(["S", "A+", "A"]).sum()) if not df_singles.empty else 0

    return {
        "singles": singles_result,
        "expresses": expresses,
        "total_stake": total_stake,
        "expected_profit": expected_profit,
        "top_count": top_count,
    }