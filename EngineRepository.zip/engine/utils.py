"""
Utility functions and classes for the betting engine.

This module provides helper functions for working with files,
calculating value and stake sizes, computing implied probabilities
from odds and implementing a simple file-based lock.  These
utilities are imported by other modules throughout the engine.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict

import numpy as np

from .config import Config


def ensure_dir(path: str | Path) -> None:
    """Ensure that the given directory exists."""
    Path(path).mkdir(parents=True, exist_ok=True)


def save_json(path: str | Path, obj: Any) -> None:
    """Serialize and save a Python object to a JSON file."""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def load_json(path: str | Path, default: Any) -> Any:
    """Load a JSON file and return its content or a default value."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def implied_prob_from_odds(o: float) -> float:
    """Compute the implied probability from a decimal odds value."""
    return 1.0 / o if o and o > 0 else 0.0


def odds_from_implied_prob(p: float) -> float:
    """Compute decimal odds from a probability value."""
    return 1.0 / p if p and p > 0 else 1000.0


def modified_kelly(p: float, b: float, shrink: float = 0.5) -> float:
    """
    Basic implementation of the Kelly criterion with a shrink factor.

    Parameters
    ----------
    p : float
        Probability of success (0..1).
    b : float
        Decimal odds minus 1 (i.e. b = odds - 1).  Must be positive.
    shrink : float, optional
        Factor to shrink the Kelly fraction to reduce volatility.  Range
        should be between 0 and 1.  Defaults to 0.5.

    Returns
    -------
    float
        Suggested fraction of bankroll to stake.  Returns 0 if b <= 0.
    """
    b0 = b - 1.0 if b > 1 else b
    if b0 <= 0:
        return 0.0
    f = (b0 * p - (1 - p)) / b0
    f = max(f, 0.0)
    return f * shrink


def kelly_fractional(prob: float, kef: float, bank: float, volatility: float) -> float:
    """
    Compute a stake size based on a fractional Kelly criterion with
    volatility adjustment.  The stake is bounded by
    `Config.MAX_BANK_FRACTION` and cannot fall below
    `Config.MIN_STAKE` if positive.

    Parameters
    ----------
    prob : float
        Probability of winning the bet.
    kef : float
        Decimal odds.
    bank : float
        Current bankroll.
    volatility : float
        Standard deviation of value across candidate bets (used to
        shrink the Kelly fraction).

    Returns
    -------
    float
        Stake size in bankroll currency.
    """
    b = kef - 1.0
    if b <= 0:
        return 0.0
    f = (prob * b - (1 - prob)) / b
    shrink = max(0.1, 1 - volatility / 0.5)  # shrink based on volatility
    f = max(0.0, f * shrink)
    stake = round(min(bank * min(f, Config.MAX_BANK_FRACTION), bank), 2)
    return max(stake, Config.MIN_STAKE) if stake > 0 else 0.0


def compute_value(prob: float, odds: float) -> float:
    """Return the expected value (EV) of a bet."""
    return float(prob * (odds - 1.0) - (1.0 - prob))


def suggest_stake(
    value: float,
    odds: float,
    bankroll: float = Config.BANKROLL,
    max_fraction: float = 0.05,
) -> float:
    """
    Suggest a stake size based on value and odds using a simple
    proportional method (not Kelly).  If the value is non-positive
    or odds are too low, returns zero.
    """
    if value <= 0 or odds <= 1.01:
        return 0.0
    b = odds - 1.0
    f = min(max_fraction, value)
    stake = round(min(bankroll * f, bankroll), 2)
    return stake


class FileLock:
    """
    Simple file-based lock to avoid concurrent writes.

    When used as a context manager, it creates a `.lock` file next to
    the target file and ensures no other process holds the lock.  The
    lock is released automatically when the context exits.
    """

    def __init__(self, path: str | Path, timeout: float = 15.0) -> None:
        self.lockfile = Path(f"{path}.lock")
        self.timeout = timeout

    def __enter__(self) -> "FileLock":
        start = time.time()
        while True:
            try:
                self.lockfile.touch(mode=0o600, exist_ok=False)
                return self
            except FileExistsError:
                if time.time() - start > self.timeout:
                    raise TimeoutError(f"Lock timeout: {self.lockfile}")
                time.sleep(0.05)

    def __exit__(self, *args: Any) -> None:
        try:
            self.lockfile.unlink(missing_ok=True)
        except Exception:
            pass