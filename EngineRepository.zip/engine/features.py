"""
Feature engineering for match data.

This module contains the `FeatureBuilder` class used to create
additional features from raw match data.  These features are fed into
the prediction model for training and inference.  The builder should
remain stateless, returning a new DataFrame with added columns.

When adding new sports or markets, extend this builder with
corresponding domain-specific features.
"""

from __future__ import annotations

import pandas as pd


class FeatureBuilder:
    """
    Construct engineered features for machine learning models.

    The `build` method takes a DataFrame of matches and produces a
    copy with new columns.  Existing columns are not modified in
    place.  You can subclass this builder or modify `build` to add
    additional features relevant to other sports or markets.
    """

    def build(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()

        # Strength differential
        if "team_home_strength" in df and "team_away_strength" in df:
            df["strength_diff"] = df["team_home_strength"] - df["team_away_strength"]

        # Form differential
        if "form_home" in df and "form_away" in df:
            df["form_diff"] = df["form_home"] - df["form_away"]

        # xG * motivation interaction
        if "home_xg" in df and "motivation_diff" in df:
            df["home_xg_motivation"] = df["home_xg"] * df["motivation_diff"]

        # Fatigue * travel interaction
        if "home_fatigue" in df and "travel_km_home" in df:
            df["home_fatigue_travel"] = df["home_fatigue"] * df["travel_km_home"]

        # Rank-based features: difference and sum of team rankings (if available).
        if "home_rank" in df and "away_rank" in df:
            try:
                home_rank_num = pd.to_numeric(df["home_rank"], errors="coerce")
                away_rank_num = pd.to_numeric(df["away_rank"], errors="coerce")
                df["rank_diff"] = (home_rank_num - away_rank_num).fillna(0)
                df["rank_sum"] = (home_rank_num + away_rank_num).fillna(0)
            except Exception:
                # If conversion fails, fallback to zeros
                df["rank_diff"] = 0
                df["rank_sum"] = 0

        # Implied probability based on bookmaker odds (if odds present).  This
        # captures the market expectation and can help the model learn
        # discrepancies between model probabilities and market odds.
        if "kef" in df:
            try:
                odds = pd.to_numeric(df["kef"], errors="coerce")
                df["implied_prob_odds"] = odds.apply(lambda x: 1.0 / x if x and x > 0 else 0.0)
            except Exception:
                df["implied_prob_odds"] = 0

        # Any missing values become zero to avoid breaking model inference
        df = df.fillna(0)
        return df