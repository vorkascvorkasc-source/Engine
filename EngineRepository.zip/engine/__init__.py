"""
Public API for the betting engine package.

This module exposes the primary components of the betting engine so that
other modules or user scripts can easily import the functionality they
need.  It re-exports configuration, the main calculation entry point,
express generation, portfolio simulation and capper handling.

When extending the engine with new modules (e.g. backtesting or data
fetching), update this file to expose those modules through a
convenient interface.
"""

from .config import Config
from .main_engine import medium_calculate
from .express import generate_express, generate_same_game_express
from .portfolio import simulate_portfolio
from .backtest.engine import backtest_multi_strategy
from .cappers import CapperHandler, capper_handler

__all__ = [
    "Config",
    "medium_calculate",
    "generate_express",
    "generate_same_game_express",
    "simulate_portfolio",
    "backtest_multi_strategy",
    "CapperHandler",
    "capper_handler",
]